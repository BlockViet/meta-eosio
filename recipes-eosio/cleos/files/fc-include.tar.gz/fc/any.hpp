#pragma once
#include <boost/any.hpp>

namespace fc { 
  // TODO: define this without using boost
  typedef boost::any any;
} 
